// b.js
import {fun, Person} from './a.js'
import fun2 from './c.js';

fun();
fun2();

var p = new Person();
console.log(p);