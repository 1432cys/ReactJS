// a.js

export function fun(){
    console.log("fun")
}

export class Person{

}

// 로컬에서 사용했음.