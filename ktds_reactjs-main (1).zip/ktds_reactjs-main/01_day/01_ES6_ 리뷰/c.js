// c.js

export default function fun2(){
    console.log("fun2")
}